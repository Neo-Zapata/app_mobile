package com.example.smartstockers;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NOMBRE = "smartStockers_db";
    private static final String TABLE_CUENTAS = "cuentas";
    private static final String TABLE_PRODUCTOS = "productos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void switchAgregar_LOGIN(View view){
        EditText et_user_LOGIN = findViewById(R.id.et_user_LOGIN);
        EditText et_password_LOGIN = findViewById(R.id.et_password_LOGIN);
        String user = et_user_LOGIN.getText().toString();
        String password = et_password_LOGIN.getText().toString();

        AdminSQLiteOpenHelper admin =  new AdminSQLiteOpenHelper
                (this, DATABASE_NOMBRE, null, DATABASE_VERSION);
        SQLiteDatabase ss_database = admin.getWritableDatabase();

        if(!user.isEmpty() && !password.isEmpty()) {
            Cursor cur = ss_database.rawQuery
                    ("select user, password, id from "+TABLE_CUENTAS+" where user ='" + user + "' and password='"+password+"'", null);
            if(cur.moveToFirst()) {
                if(cur.getString(0).equals(user) && cur.getString(1).equals(password)) {
                    String id = cur.getString(2);
                    Intent Login_ = new Intent(this, Agregar.class);
                    Login_.putExtra("id", id);
                    startActivity(Login_);
                    et_user_LOGIN.setText("");
                    et_password_LOGIN.setText("");
                    Toast.makeText(this, "Esta logueado con el usuario: "+user,Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Ha sucedido un error al loguearse", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(this, "User o Password incorrectos", Toast.LENGTH_LONG).show();
                et_user_LOGIN.setText("");
                et_password_LOGIN.setText("");
            }
            cur.close();
        } else {
            Toast.makeText(this, "LLenar ambos campos es obligatorio", Toast.LENGTH_LONG).show();
        }
        ss_database.close();
    }
    public void switchRegister_LOGIN(View view){
     Intent Register = new Intent(this, Registro.class);
     startActivity(Register);
    }







}