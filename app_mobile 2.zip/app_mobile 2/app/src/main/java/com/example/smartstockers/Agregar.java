package com.example.smartstockers;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


public class Agregar extends AppCompatActivity {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NOMBRE = "smartStockers_db";
    private static final String TABLE_CUENTAS = "cuentas";
    private static final String TABLE_PRODUCTOS = "productos";

    Button btnScan;
    EditText et_codigo_AGREGAR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);




// Inicio Scaner -----------------------------------------------------------------------------------------------


        btnScan = findViewById(R.id.btn_scan_AGREGAR);
        et_codigo_AGREGAR = findViewById(R.id.et_codigo_AGREGAR);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator integrator = new IntentIntegrator(Agregar.this);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
                integrator.setPrompt("Escanea el producto para agregarlo");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(true);
                integrator.setBarcodeImageEnabled(true);
                integrator.initiateScan();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(result != null){
            if(result.getContents() == null){
                Toast.makeText(this, "Lectura cancelada", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                et_codigo_AGREGAR.setText(result.getContents());
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
// Fin Scaner -----------------------------------------------------------------------------------------------

// el menu superior derecho es visible
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }
    // acciones de las opciones del menu

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        String id = getIntent().getStringExtra("id");
        switch (item.getItemId()){
            case R.id.logout_MENU:
                Intent login_ = new Intent(this, MainActivity.class);
                startActivity(login_);
                break;
            case R.id.consumir_MENU:
                Intent consumir_ = new Intent(this, Consumir.class);
                consumir_.putExtra("id", id);
                startActivity(consumir_);
                break;
            case R.id.verstock_MENU:
                Intent stock_ = new Intent(this, Stock.class);
                stock_.putExtra("id", id);
                startActivity(stock_);
                break;
            case R.id.agregar_MENU:
                Toast toast2 = Toast.makeText(this, "Ya se encuentra en Agregar", Toast.LENGTH_SHORT);
                toast2.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void add_process(View view) {
        EditText et_producto_AGREGAR = findViewById(R.id.et_producto_AGREGAR);
        EditText et_cantidad_AGREGAR = findViewById(R.id.et_cantidad_AGREGAR);
        EditText et_FV_AGREGAR = findViewById(R.id.et_FV_AGREGAR);
        EditText et_categoria_AGREGAR = findViewById(R.id.et_categoria_AGREGAR);
        EditText et_codigo_AGREGAR = findViewById(R.id.et_codigo_AGREGAR);
        EditText et_precio_AGREGAR = findViewById(R.id.et_precio_AGREGAR);
        EditText et_ubicacion_AGREGAR = findViewById(R.id.et_ubicacion_AGREGAR);
        String producto = et_producto_AGREGAR.getText().toString();
        String cantidad = et_cantidad_AGREGAR.getText().toString();
        String vencimiento = et_FV_AGREGAR.getText().toString();
        String categoria = et_categoria_AGREGAR.getText().toString();
        String codigo = et_codigo_AGREGAR.getText().toString();
        String precio = et_precio_AGREGAR.getText().toString();
        String ubicacion = et_ubicacion_AGREGAR.getText().toString();

        AdminSQLiteOpenHelper admin =  new AdminSQLiteOpenHelper
                (this, DATABASE_NOMBRE, null, DATABASE_VERSION);
        SQLiteDatabase ss_database = admin.getWritableDatabase();

        if(!producto.isEmpty() && !cantidad.isEmpty() && !vencimiento.isEmpty() && !categoria.isEmpty()
                && !codigo.isEmpty() && !precio.isEmpty() && !ubicacion.isEmpty()) {
            if(Integer.parseInt(cantidad) < 0) {
                Toast.makeText(this, "La cantidad tiene que ser mayor a 0.", Toast.LENGTH_LONG).show();
            } else {
                //insert productos
                String id = getIntent().getStringExtra("id");
                ContentValues data = new ContentValues();
                data.put("cantidad", cantidad);
                data.put("producto", producto);
                data.put("vencimiento", vencimiento);
                data.put("categoria", categoria);
                data.put("codigo", codigo);
                data.put("precio", precio);
                data.put("ubicacion", ubicacion);
                data.put("id_cuentas", id);
                ss_database.insert(TABLE_PRODUCTOS, null, data);

                ss_database.close();
                et_producto_AGREGAR.setText("");
                et_cantidad_AGREGAR.setText("");
                et_FV_AGREGAR.setText("");
                et_categoria_AGREGAR.setText("");
                et_codigo_AGREGAR.setText("");
                et_precio_AGREGAR.setText("");
                et_ubicacion_AGREGAR.setText("");
                Toast.makeText(this, "Los productos se añadieron correctamente", Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(this, "Llenar todos los campos", Toast.LENGTH_SHORT).show();
        }
    }
}
