package com.example.smartstockers;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NOMBRE = "smartStockers_db";
    private static final String TABLE_CUENTAS = "cuentas";
    private static final String TABLE_PRODUCTOS = "productos";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
    }
// metodo para registrar una cuenta
    public void register_process(View view) {
        EditText et_email_REGISTER = findViewById(R.id.et_email_REGISTER);
        EditText et_user_REGISTER = findViewById(R.id.et_user_REGISTER);
        EditText et_password_REGISTER = findViewById(R.id.et_password_REGISTER);
        String email = et_email_REGISTER.getText().toString();
        String user = et_user_REGISTER.getText().toString();
        String password = et_password_REGISTER.getText().toString();

        AdminSQLiteOpenHelper admin =  new AdminSQLiteOpenHelper
                (this, DATABASE_NOMBRE, null, DATABASE_VERSION);
        SQLiteDatabase ss_database = admin.getWritableDatabase();

        if(!email.isEmpty() && !user.isEmpty() && !password.isEmpty()) {

            Cursor cur = ss_database.rawQuery
                    ("select email from "+TABLE_CUENTAS+" where email ='" + email + "'", null);
            Cursor cur2 = ss_database.rawQuery
                    ("select user from "+TABLE_CUENTAS+" where user='" + user + "'",null);

            if(cur.moveToFirst()) {
                Toast.makeText(this, "Ese E-mail ya esta registrado.", Toast.LENGTH_LONG).show();
                ss_database.close();
            } else if(cur2.moveToFirst()) {
                Toast.makeText(this, "Ese User ya esta registrado.", Toast.LENGTH_LONG).show();
                ss_database.close();
            } else {
                //insert cuentas
                ContentValues data = new ContentValues();
                data.put("email", email);
                data.put("user", user);
                data.put("password", password);
                ss_database.insert(TABLE_CUENTAS, null, data);

                ss_database.close();
                et_email_REGISTER.setText("");
                et_user_REGISTER.setText("");
                et_password_REGISTER.setText("");
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_LONG).show();
            }
            cur.close();
            cur2.close();
        } else {
            Toast.makeText(this, "Llenar todos los campos", Toast.LENGTH_LONG).show();
        }
    }

    public void switchMainActivity(View view){
        Intent Volver_ = new Intent(this, MainActivity.class);
        startActivity(Volver_);
    }


}