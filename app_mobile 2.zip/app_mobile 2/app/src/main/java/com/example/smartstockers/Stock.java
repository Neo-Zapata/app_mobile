package com.example.smartstockers;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Stock extends AppCompatActivity {

    ListView listViewProductos;

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NOMBRE = "smartStockers_db";
    private static final String TABLE_CUENTAS = "cuentas";
    private static final String TABLE_PRODUCTOS = "productos";


    ArrayList<String> listaData;
    ArrayList<productos> listaProductos;
    AdminSQLiteOpenHelper conn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);



        listViewProductos = findViewById(R.id.lv_stock);
        conn = new AdminSQLiteOpenHelper(this, DATABASE_NOMBRE, null, DATABASE_VERSION);
        consultarListaProductos();

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, listaData);
        listViewProductos.setAdapter(adapter);

    }

    private void consultarListaProductos() {
        String id = getIntent().getStringExtra("id");
        SQLiteDatabase ss_database = conn.getReadableDatabase();
        productos producto = null;
        listaProductos = new ArrayList<productos>();
        Cursor cursor = ss_database.rawQuery("SELECT * FROM "+TABLE_PRODUCTOS+" WHERE id_cuentas="+id, null);

        while(cursor.moveToNext()) {
            producto = new productos();
            producto.setId          (cursor.getInt(0));
            producto.setId_cuentas  (cursor.getInt(1));
            producto.setCodigo      (cursor.getInt(2));
            producto.setProducto    (cursor.getString(3));
            producto.setCategoria   (cursor.getString(4));
            producto.setUbicacion   (cursor.getString(5));
            producto.setPrecio      (cursor.getInt(6));
            producto.setVencimiento (cursor.getString(7));
            producto.setCantidad    (cursor.getInt(8));

            listaProductos.add(producto);
        }
        obtenerLista();
    }

    private void obtenerLista() {
        listaData = new ArrayList<String>();

        for (int i = 0; i<listaProductos.size();i++){
            listaData.add("\nProducto: "+listaProductos.get(i).getProducto()+
                    "       -       Codigo: "+listaProductos.get(i).getCodigo()+
                    "\nPrecio: "+listaProductos.get(i).getPrecio()+
                    "       -       Cantidad: "+listaProductos.get(i).getCantidad()+
                    "\nCategoria: "+listaProductos.get(i).getCategoria()+
                    "       -       Ubicacion: "+listaProductos.get(i).getUbicacion()+"\n");
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        String id = getIntent().getStringExtra("id");
        switch (item.getItemId()){
            case R.id.consumir_MENU:
                Intent Consumir_ = new Intent(this, Consumir.class);
                Consumir_.putExtra("id", id);
                startActivity(Consumir_);
                break;
            case R.id.agregar_MENU:
                Intent Agregar_ = new Intent(this, Agregar.class);
                Agregar_.putExtra("id", id);
                startActivity(Agregar_);
                break;
            case R.id.logout_MENU:
                Intent login_ = new Intent(this, MainActivity.class);
                startActivity(login_);
                break;
            case R.id.verstock_MENU:
                Toast.makeText(this, "Ya se encuentra en el Stock", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}