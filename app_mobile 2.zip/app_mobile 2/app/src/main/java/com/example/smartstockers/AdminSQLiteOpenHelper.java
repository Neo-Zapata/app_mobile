package com.example.smartstockers;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

// esta clase administra la base de datos
public class AdminSQLiteOpenHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NOMBRE = "smartStockers_db";
    private static final String TABLE_CUENTAS = "cuentas";
    private static final String TABLE_PRODUCTOS = "productos";

    //constructor
    public AdminSQLiteOpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NOMBRE, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase ss_database) {
        //tabla cuentas
        ss_database.execSQL("CREATE TABLE " +TABLE_CUENTAS+"(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "email TEXT NOT NULL," +
                "user TEXT NOT NULL," +
                "password TEXT NOT NULL)");
        //tabla productos
        ss_database.execSQL("CREATE TABLE " +TABLE_PRODUCTOS+"(" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "id_cuentas INTEGER NOT NULL," +
                "codigo INTEGER NOT NULL," +
                "producto TEXT NOT NULL," +
                "categoria TEXT NOT NULL," +
                "ubicacion TEXT NOT NULL," +
                "precio INTEGER NOT NULL," +
                "vencimiento TEXT NOT NULL," +
                "cantidad INTEGER NOT NULL," +
                "FOREIGN KEY(id_cuentas) REFERENCES cuentas(id))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase ss_database, int oldVersion, int newVersion) {
        ss_database.execSQL("DROP TABLE "+TABLE_CUENTAS);
        ss_database.execSQL("DROP TABLE "+TABLE_PRODUCTOS);
        onCreate(ss_database);
    }
}
