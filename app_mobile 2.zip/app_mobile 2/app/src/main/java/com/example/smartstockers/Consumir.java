package com.example.smartstockers;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


public class Consumir extends AppCompatActivity {

    private static final int DATABASE_VERSION = 2;
    private static final String DATABASE_NOMBRE = "smartStockers_db";
    private static final String TABLE_CUENTAS = "cuentas";
    private static final String TABLE_PRODUCTOS = "productos";

    Button btnScan2;
    EditText et_producto_CONSUMIR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumir);

// Inicio Scaner -----------------------------------------------------------------------------------------------

        btnScan2 = findViewById(R.id.btnScan);
        et_producto_CONSUMIR = findViewById(R.id.et_producto_CONSUMIR);

        btnScan2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                IntentIntegrator integrator = new IntentIntegrator(Consumir.this);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
                integrator.setPrompt("Escanea el producto para consumirlo");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(true);
                integrator.setBarcodeImageEnabled(true);
                integrator.initiateScan();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(result != null){
            if(result.getContents() == null){
                Toast.makeText(this, "Lecutura cancelada", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
                et_producto_CONSUMIR.setText(result.getContents());
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

// Fin Scaner -----------------------------------------------------------------------------------------------

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        String id = getIntent().getStringExtra("id");
        switch (item.getItemId()){
            case R.id.logout_MENU:
                Intent login_ = new Intent(this, MainActivity.class);
                startActivity(login_);
                break;
            case R.id.agregar_MENU:
                Intent Agregar_ = new Intent(this, Agregar.class);
                Agregar_.putExtra("id", id);
                startActivity(Agregar_);
                break;
            case R.id.verstock_MENU:
                Intent Stock_ = new Intent(this, Stock.class);
                Stock_.putExtra("id", id);
                startActivity(Stock_);
                break;
            case R.id.consumir_MENU:
                Toast.makeText(this, "Ya se encuentra en Consumir", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    public void Consumir_process(View view) {
        EditText et_producto_o_codigo_CONSUMIR = findViewById(R.id.et_producto_CONSUMIR);
        EditText et_cantidad_CONSUMIR = findViewById(R.id.et_cantidad_CONSUMIR);
        String producto_o_codigo = et_producto_o_codigo_CONSUMIR.getText().toString();
        String cantidad = et_cantidad_CONSUMIR.getText().toString();

        if(!producto_o_codigo.isEmpty() && !cantidad.isEmpty()) {
            String producto = "producto";
            String codigo = "codigo";
            if(Integer.parseInt(cantidad) >= 1) {

                boolean consumirByName = consumir(producto);
                boolean consumirByCode = consumir(codigo);

                et_producto_o_codigo_CONSUMIR.setText("");
                et_cantidad_CONSUMIR.setText("");

                if (consumirByName) {
                    Toast.makeText(this, "Se consumio correctamente", Toast.LENGTH_SHORT).show();
                } else if (consumirByCode) {
                    Toast.makeText(this, "Se consumio correctamente", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "El codigo o producto no existe", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(this, "La cantidad debe ser mayor a 0", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Llene todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean consumir(String prod_o_cod) {
        AdminSQLiteOpenHelper admin =  new AdminSQLiteOpenHelper
                (this, DATABASE_NOMBRE, null, DATABASE_VERSION);
        SQLiteDatabase ss_database = admin.getWritableDatabase();

        EditText et_producto_o_codigo_CONSUMIR = findViewById(R.id.et_producto_CONSUMIR);
        EditText et_cantidad_CONSUMIR = findViewById(R.id.et_cantidad_CONSUMIR);
        String producto_o_codigo = et_producto_o_codigo_CONSUMIR.getText().toString();
        String cantidad = et_cantidad_CONSUMIR.getText().toString();
        String id = getIntent().getStringExtra("id");

        boolean validation = false;

        Cursor cur = ss_database.rawQuery
                ("select cantidad from "+TABLE_PRODUCTOS+" where id_cuentas="+id+" and "+prod_o_cod+"='"+producto_o_codigo+"'" , null);

        if (cur.moveToFirst()) {
            String cant = cur.getString(0);
            int new_cant = Integer.parseInt(cant) - Integer.parseInt(cantidad);
            if(new_cant < 0) {
                Toast.makeText(this, "La cantidad ingresada debe ser menor o igual a "+cant+".", Toast.LENGTH_SHORT).show();
            } else if(new_cant == 0) {
                ss_database.delete(TABLE_PRODUCTOS, prod_o_cod+"='"+producto_o_codigo+"' and id_cuentas="+id, null);
                validation = true;
            } else {
                ContentValues data = new ContentValues();
                data.put("cantidad", new_cant);
                ss_database.update(TABLE_PRODUCTOS,data,prod_o_cod+"='"+producto_o_codigo+"' and id_cuentas="+id, null);
                validation = true;
            }
        }
        ss_database.close();
        cur.close();
        return validation;
    }
}